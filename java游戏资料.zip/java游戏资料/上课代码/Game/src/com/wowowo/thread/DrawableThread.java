package com.wowowo.thread;

import com.wowowo.view.MyPanel;

public class DrawableThread extends Thread{
	
	  public MyPanel myPanel;
	  
	  public DrawableThread(MyPanel myPanel)
	  {
		    this.myPanel=myPanel;
		    
	  }
	  
	  public void run()
	  {
		  while(true)
		  {
			    myPanel.repaint();
			    
			    try {
					this.currentThread().sleep(1);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		  }
	  }

}
