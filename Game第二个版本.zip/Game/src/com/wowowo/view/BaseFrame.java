package com.wowowo.view;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;

import com.wowowo.listener.FrameMouseListener;
import com.wowowo.model.Enemy;
import com.wowowo.model.Enemy001;

public class BaseFrame extends JFrame{
	
	  public static int frameWidth=512;
	  public static int frameHeight=768;
	  public  MyPanel panel; 
	  public FrameMouseListener frameMouseListener;
	  
	  public static boolean hasPlayer;
	  
	  public static boolean hasCount;
	  
	  public static boolean hasItem;
	  
	  public void createPlayer()
	  {
		   hasPlayer=true;
	  }
	  
	  public void setTouchListener()
	  {
		   this.frameMouseListener=new FrameMouseListener();
		   this.frameMouseListener.baseFrame=this;
		   this.addMouseListener(this.frameMouseListener);
	  }
	  
	  public void addEnemyType(Class c)
	  {
		   this.panel.enemiesType.add(c);
	  }
	
	  public void setPlayerPowerLevel(int attachMode)
	  {
		  this.panel.player.attackMode=attachMode;
	  }
	  
	  public void setEnemeyHasItem()
	  {
		  hasItem=true;
	  }
	  
	  public void setCount()
	  {
		  hasCount=true;
	  }
	  
	   public BaseFrame(){
		   
		    super("ֱ���ɻ���ս");
			Dimension screenSize =Toolkit.getDefaultToolkit().getScreenSize(); //�����Ļ�ĳߴ磨�ֱ��ʣ�
			setBounds( ((int)screenSize.getWidth() - frameHeight) / 2, 0, frameWidth, frameHeight);
			setLayout(null);
			this.panel = new MyPanel();
			this.panel.setBounds(0, 0, this.getWidth(), this.getHeight());
			this.add(this.panel);
			
			//���ü�����
			//setTouchListener();
			
			//addEnemyType(Enemy001.class);
			
			setVisible(true);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		     
		     
		   
	   }
	
	
	   

}
