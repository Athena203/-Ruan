package com.wowowo.view;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		   new MainFrame();
	}

}
