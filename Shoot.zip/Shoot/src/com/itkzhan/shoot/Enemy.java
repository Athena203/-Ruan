package com.itkzhan.shoot;

public interface Enemy {
	int getScore();
}
